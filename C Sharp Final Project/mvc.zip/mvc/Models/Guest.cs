namespace mvc.Models
{
    public class Guest
    {
        public string nameGuest{get;set;}
        public bool childs {get;set;}
        public int numberPersons {get;set;}
        public int numberTable {get;set;}

        
        public string status {get;set;} 
        }
    }
