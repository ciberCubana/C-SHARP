namespace mvc.Models
{
    public class TODO
    {
        public string taskname {get;set;}
        public string description{get;set;}

        public string taskdue{get;set;}
    }
}