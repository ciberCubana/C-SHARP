using System.Collections.Generic;

namespace mvc.Models
{
    public class Party
    {
        public string name {get;set;}
        public string kind {get;set;}
        public string date {get;set;}
        public string message {get;set;}

        public string venue{get;set;}

        

    }
}